#!/bin/bash

echo "Part One:"
echo
cat << _EOF_
 _____ _               _                _              _             
|_   _| |__   ___     / \__      ____ _| | _____ _ __ (_)_ __   __ _ 
  | | | '_ \ / _ \   / _ \ \ /\ / / _' | |/ / _ \ '_ \| | '_ \ / _' |
  | | | | | |  __/  / ___ \ V  V / (_| |   <  __/ | | | | | | | (_| |
  |_| |_| |_|\___| /_/   \_\_/\_/ \__,_|_|\_\___|_| |_|_|_| |_|\__, |
                                                               |___/ 
_EOF_

echo
cat << _EOF_
It was a dark and stormy night, long ago in the wilderness of Yorg.
A sweet and gentle Kippums roamed the land, in search of love, driven
by a purpose so raw and divine that even she knew not what was in
store for her.

The trees in Yorg are not like other trees, they speak an ancient
language: The language of the Yews. The first clue Kippums seeks can
be found in the realm of the Yews, hidden deep within the depths,
there is a sacred channel, known as the marriage of Kippums' first
born child and the perfect age. Find this sacred place and the code
to part two yee shall find...
_EOF_

echo

GUESSED=1
while ((GUESSED)); do
  read -p "Enter the passphrase to go to the next part, or 'q' to quit: " YEW
  case "$YEW" in
    q|Q) 
      GUESSED=0
      quit_adventure
      ;;
    kippumsISsoCUTE)
      GUESSED=0
      source resources/part2.sh
      ;;
    *) echo "Wrong passphrase, try again..."
  esac
done

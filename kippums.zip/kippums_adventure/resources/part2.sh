#!/bin/bash

clear
echo "Part Two:"
cat << _EOF_
 _  ___             __        ___               
| |/ (_)___ ___ _   \ \      / (_)___ ___ _   _ 
| ' /| / __/ __| | | \ \ /\ / /| / __/ __| | | |
| . \| \__ \__ \ |_| |\ V  V / | \__ \__ \ |_| |
|_|\_\_|___/___/\__, | \_/\_/  |_|___/___/\__, |
                |___/                     |___/ 
_EOF_

echo
cat << _EOF_
Despite being so small, Kippums is a very smart and wonderful
creature! She found her way through the forest of Yorg and Lo!
-- Behold! There before her was a clearing.

"Who goes there?" asked a small, trembling voice. "I see you are
small, so whilst I am scared, I believe perhaps I can trust you.."

Kippums looked around and saw the tiniest, littlest, most
miniscule man named Francis. She greeted him and he presented her
with an intriguing option:

"I may be small," Francis said.

There was a long, long pause. "Umm, are you going to finish?" asked
Kippums.

"Oh.." ".." I did, replied Francis.

Kippums realized the clue was somewhere to be found in this
exchange. When a meme is incomplete... is it on purpose?
_EOF_

echo
echo "For the next part, go to 'http://astridlyre.github.io/{passphrase}/'"

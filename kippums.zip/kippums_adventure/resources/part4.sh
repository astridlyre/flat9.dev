#!/bin/bash

echo "Part Four:"
cat << _EOF_
 _____                  _                   '
|_   _| __ _   _  ___  | |    _____   _____ '
  | || |__| | | |/ _ \ | |   / _ \ \ / / _ \'
  | || |  | |_| |  __/ | |__| (_) \ V /  __/'
  |_||_|   \__,_|\___| |_____\___/ \_/ \___|'
                                            '
_EOF_

echo
cat << _EOF_
At long last, a Kippums has solved the mystery of the secret
gibberish that Mr. Rock was cooking in his mouth hole. Huzzah!

She made her way through the valley, around the lake, and there,
in front of her, was a pale and languid person...

"My love!" they cried. "It's me, Astrid!"

They spoke, but they could not more. Indeed, it seems that this
figure was frozen, afixed to the ground and immobile.

"I have been cursed by Steven the witch!" they lamented. "Please,
Kippums, you're my only hope. Steven said that I could only be
freed if the correct three words were spoken."

To Finish This Quest, speak the secret three phrases (in all lowercase).
_EOF_

echo

PHRASE_ONE=1
PHRASE_TWO=1
PHRASE_THREE=1
DONE=1

while ((DONE)); do
  while ((PHRASE_ONE)); do
    read -p "First phrase is 'we kissed outside _ the store': " ONE
    if [[ "$ONE" == "black friday" ]]; then
      PHRASE_ONE=0
    else
      echo "Ouch! Wrong phrase... Astrid is still frozen."
    fi
  done
  while ((PHRASE_TWO)); do
    read -p "Second phrase is 'davey _ ': " TWO
    if [[ "$TWO" == "winks" ]]; then
      PHRASE_TWO=0
    else
      echo "Oh dear GOD! It's hurting!! Astrid can't move.."
    fi
  done
  while ((PHRASE_THREE)); do
    read -p "Third phrase is 'elizabeth ann _': " THREE
    if [[ "$THREE" == "kitten" ]]; then
      PHRASE_THREE=0
    else
      echo "Well, this is awkward, Astrid is becoming rigid.."
    fi
  done
  echo
  echo "Congratulations! You have proven your wit and have earned..."
  sleep 2
  for x in {1..100}; do
    echo "$x rubbums"
  done
  DONE=0
done




#!/bin/bash

quit_adventure() {
  echo "Very well, farewell!"
  exit 0
}

start_adventure() {
  echo "Started!"
  sleep 1
  clear
  source resources/part1.sh
}

read -p "Welcome to Kippum's Adventure. Ready to begin? [y/n] " READY

case "$READY" in
  y|Y) start_adventure ;;
  superSECRETkippumPASSPHRASE) source resources/part4.sh ;;
  *) quit_adventure
esac
